export { PdfPasswordModal, type PdfPasswordModalProps } from './PdfPasswordModal';
