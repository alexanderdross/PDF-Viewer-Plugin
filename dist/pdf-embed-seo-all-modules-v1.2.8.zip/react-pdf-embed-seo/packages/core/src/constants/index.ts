/**
 * Constants exports for @pdf-embed-seo/core
 */

export * from './defaults';
