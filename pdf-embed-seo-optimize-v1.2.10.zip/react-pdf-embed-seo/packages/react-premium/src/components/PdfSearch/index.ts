export { PdfSearchBar, type PdfSearchBarProps, type PdfSearchResult } from './PdfSearchBar';
